# هنا تضع كود البوت الحقيقي
print("Bot is ready.") 
